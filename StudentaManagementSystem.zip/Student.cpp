#include "Student.h"

Student::Student() : left(nullptr), right(nullptr), next(nullptr){}

Student::~Student(){}
